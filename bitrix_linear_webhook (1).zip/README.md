# Webhook Bitrix24 → Linear (Deploy no Render)
Siga os passos do README dentro do ChatGPT para obter o LINEAR_TEAM_ID, configurar variáveis de ambiente e publicar no Render.
